#add.py
def add(x, y):
  result = x+y
  return result
result=add(x,y)