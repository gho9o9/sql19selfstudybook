﻿
/* *********************************************************************** */
/*   Support_for_UTF-8_character_encoding.sql                              */
/* *********************************************************************** */

/* ============================================= */
/* サンプルデータベースを作成する                */
/* ============================================= */

/* ■■ 1 つ目のクエリ ■■ */

USE master;
GO
-- テスト用の3つのサンプルデータベースを作成
CREATE DATABASE DB01 COLLATE Japanese_XJIS_140_CS_AS_KS_WS;
GO
CREATE DATABASE DB02 COLLATE Japanese_XJIS_140_CS_AS_KS_WS;
GO
CREATE DATABASE DB03 COLLATE Japanese_XJIS_140_CS_AS_KS_WS_UTF8;
GO


/* ■■ 2 つ目のクエリ ■■ */

USE master;
GO
-- UTF-8に対応する照合順序のリスト
SELECT name, description FROM fn_helpcollations() WHERE name LIKE '%UTF8';
GO
-- 日本語でUTF-8に対応する照合順序のリスト
SELECT name, description FROM fn_helpcollations() WHERE name LIKE 'Japanese%UTF8';
GO


/* ============================================= */
/* 非 Unicode データベースにデータを登録する     */
/* ============================================= */

USE DB01;
GO
-- ループ処理のパフォーマンス向上のためカウント処理をOFFに設定
SET NOCOUNT ON;
-- Unicode未対応のサンプルテーブルを作成
CREATE TABLE dbo.non_unicode_table (
  id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  col1 varchar(50) NOT NULL
);
GO

-- ランダムなアルファベット文字列を100万件登録
BEGIN TRANSACTION;
DECLARE @i int = 1;
WHILE @i <= 10000
BEGIN
  INSERT INTO dbo.non_unicode_table (col1) 
  SELECT REPLICATE(CONCAT(
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25))),
    CHAR(FLOOR(65 + (RAND() * 25)))
    ), 5);
  SET @i += 1;
END;
COMMIT TRANSACTION;
GO
-- 登録されたデータ件数を確認
SELECT COUNT(*) FROM dbo.non_unicode_table;
GO


/* ============================================= */
/* 非 Unicode データベースを Unicode 対応データ  */
/* ベースに移行する                              */
/* ============================================= */

/* ■■ 手順 1. ■■ */

USE DB02;
GO
-- varcharからnvarcharに列定義を変換したテーブルを作成
CREATE TABLE dbo.utf16_table(
  id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  col1 nvarchar(50) NOT NULL
);
GO
-- 移行元の「non_unicode_table」テーブルからデータを移行
BEGIN TRANSACTION;
  INSERT INTO dbo.utf16_table(col1) SELECT col1 FROM DB01.dbo.non_unicode_table;
COMMIT TRANSACTION;


/* ■■ 手順 2. ■■ */

USE DB03;
GO
-- 移行元と同一定義でテーブルを作成
CREATE TABLE dbo.utf8_table(
  id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
  col1 varchar(50) NOT NULL
);
GO
-- 移行元の「non_unicode_table」からデータを登録
BEGIN TRANSACTION;
  INSERT INTO dbo.utf8_table(col1) SELECT col1 FROM db01.dbo.non_unicode_table;
COMMIT TRANSACTION;


/* ■■ 手順 3. ■■ */

USE DB01;
GO
-- 移行元の「non_unicode_table」テーブルの容量を確認
EXEC sp_spaceused N'dbo.non_unicode_table';
GO

USE DB02;
GO
-- UTF-16エンコードの「utf16_table」テーブルの容量を確認
EXEC sp_spaceused N'dbo.utf16_table';
GO

USE DB03;
GO
-- UTF-8エンコードの「utf8_table」テーブルの容量を確認
EXEC sp_spaceused N'dbo.utf8_table';
GO


/* ============================================= */
/* ハンズオン用環境をクリーンアップする          */
/*   ※ 必要に応じてクリーンアップに使用ください */
/* ============================================= */

USE master;
GO
-- 既存の接続を閉じてシングルユーザーモードに変更
ALTER DATABASE DB01 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE DB02 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE DB03 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
-- サンプルデータベース「DB01」「DB02」「DB03」を削除
DROP DATABASE DB01;
DROP DATABASE DB02;
DROP DATABASE DB03;
GO
-- サンプルデータベース「DB01」「DB02」「DB03」が削除されたことを確認
SELECT * FROM sys.databases WHERE name in (N'DB01', N'DB02', N'DB03');
GO

