
/* ******************************************************************* */
/*   Optimize_for_sequential_key_insert_performance.sql                */
/* ******************************************************************* */

/* ------------------------------------------------------------------- */
/* ���O����                                                            */
/* ------------------------------------------------------------------- */

/* ============================================= */
/* �T���v���e�[�u���̍쐬                        */
/* ============================================= */

USE WideWorldImportersDW;
GO
-- �e�[�u���Ǝ�L�[�쐬 (OPTIMIZE_FOR_SEQUENTIAL_KEY�͖����ɐݒ�)
CREATE TABLE dbo.Order_SequentialKey(  
  [Order Key] bigint IDENTITY(1,1) NOT NULL,
  [City Key] int NOT NULL,
  [Customer Key] int NOT NULL,
  [Stock Item Key] int NOT NULL,
  [Order Date Key] date NOT NULL,
  [Picked Date Key] date NULL,
  [Description] nvarchar(100) NOT NULL
CONSTRAINT PK_Fact_Order PRIMARY KEY CLUSTERED (
  [Order Key] ASC
));
GO

-- �e�[�u���Ǝ�L�[�쐬 (OPTIMIZE_FOR_SEQUENTIAL_KEY�͗L���ɐݒ�)
CREATE TABLE dbo.Order_SequentialKey_Optimized(
  [Order Key] [bigint] IDENTITY(1,1) NOT NULL,
  [City Key] [int] NOT NULL,
  [Customer Key] [int] NOT NULL,
  [Stock Item Key] [int] NOT NULL,
  [Order Date Key] [date] NOT NULL,
  [Picked Date Key] [date] NULL,
  [Description] [nvarchar](100) NOT NULL
CONSTRAINT [PK_Fact_Order_Optimized] PRIMARY KEY CLUSTERED (
  [Order Key] ASC
) WITH (OPTIMIZE_FOR_SEQUENTIAL_KEY=ON));
GO

